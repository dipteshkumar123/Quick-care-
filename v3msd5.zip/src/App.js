import React, { useState } from "react";
import { format } from "date-fns";

export default function QuickCareSimplified() {
  const [step, setStep] = useState(1);
  const [selectedDoctor, setSelectedDoctor] = useState("");
  const [date, setDate] = useState("");
  const [userName, setUserName] = useState("");

  const doctors = ["Dr. Asha Mehta", "Dr. Rahul Sen", "Dr. Priya Khanna"];

  const handleBooking = () => {
    if (selectedDoctor && userName && date) {
      setStep(2);
    }
  };

  return (
    <div
      style={{
        maxWidth: "500px",
        margin: "auto",
        padding: "20px",
        fontFamily: "Arial",
      }}
    >
      <h1
        style={{ fontSize: "24px", fontWeight: "bold", marginBottom: "20px" }}
      >
        QuickCare - Book a Consultation
      </h1>

      {step === 1 && (
        <div style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
          <input
            type="text"
            placeholder="Enter your name"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
            style={{
              padding: "10px",
              border: "1px solid #ccc",
              borderRadius: "6px",
            }}
          />

          <select
            value={selectedDoctor}
            onChange={(e) => setSelectedDoctor(e.target.value)}
            style={{
              padding: "10px",
              border: "1px solid #ccc",
              borderRadius: "6px",
            }}
          >
            <option value="">--Choose Doctor--</option>
            {doctors.map((doc) => (
              <option key={doc} value={doc}>
                {doc}
              </option>
            ))}
          </select>

          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            style={{
              padding: "10px",
              border: "1px solid #ccc",
              borderRadius: "6px",
            }}
          />

          <button
            onClick={handleBooking}
            style={{
              padding: "12px",
              backgroundColor: "#28a745",
              color: "white",
              border: "none",
              borderRadius: "6px",
            }}
          >
            Book Consultation
          </button>
        </div>
      )}

      {step === 2 && (
        <div
          style={{
            border: "1px solid #ddd",
            borderRadius: "10px",
            padding: "20px",
          }}
        >
          <h2 style={{ fontSize: "20px", fontWeight: "bold" }}>
            Booking Confirmed 🎉
          </h2>
          <p>
            <strong>Name:</strong> {userName}
          </p>
          <p>
            <strong>Doctor:</strong> {selectedDoctor}
          </p>
          <p>
            <strong>Date:</strong> {format(new Date(date), "PPP")}
          </p>
          <a
            href="https://meet.jit.si/quickcare-demo-room"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              display: "inline-block",
              marginTop: "15px",
              color: "#007bff",
              textDecoration: "underline",
            }}
          >
            Join Video Consultation
          </a>
        </div>
      )}
    </div>
  );
}
